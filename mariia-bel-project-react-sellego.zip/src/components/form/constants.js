export const options = [
    {
        text: 'Выбор 1',
        value: 'chose1'
    },
    {
        text: 'Выбор 2',
        value: 'chose2'
    },
    {
        text: 'Выбор 3',
        value: 'chose3'
    },
    {
        text: 'Выбор 4',
        value: 'chose4'
    },
    {
        text: 'Выбор 5',
        value: 'chose5'
    },
]

export const content = {
    selector: "Выбор чего-то *",
    phone: "Номер телефона *",
    more: "Коротко о чем-то еще",
    file: "Прикрепить файл",
    btn: "Кнопка"
}